import os

class Config(object):
    SECRET_KEY = 'qLeJHyZFTClgHixL'
    SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:@localhost/jarvis_db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

class DevelopmentConfig(Config):
    DEBUG = True

class ProductionConfig(Config):
    DEBUG = False

class DevelopmentConfig(Config):
    DEBUG = True
    MYSQL_HOST = 'localhost'
    MYSQL_USER = 'root'
    MYSQL_PASSWORD = ''
    MYSQL_DB = 'jarvis_db'

class ProductionConfig(Config):
    DEBUG = False