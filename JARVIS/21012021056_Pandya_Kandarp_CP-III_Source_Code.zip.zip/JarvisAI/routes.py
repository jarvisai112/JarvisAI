from flask import Blueprint, jsonify, request, redirect, url_for, session, render_template, flash
from models import db, User
from assistant import process_user_input, transcribe_audio
from forms import LoginForm, SignupForm, ProfileUpdateForm, SubscriptionForm  # Add ProfileUpdateForm here
import os
import stripe

routes = Blueprint('routes', __name__)

# Stripe configuration
stripe.api_key = "sk_test_51QPSn5Jisl6x66W2mjFWCVxZJfd1qMoSgyOIUMoTCke38JxqfHi0zYaIEsVFxb3rtrdWGAe8FImWlHaJ8pSLl0yK002NGXfgEf" 

@routes.route('/')
def home():
    return render_template('index.html')

@routes.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.check_password(form.password.data):
            session['user_id'] = user.id
            return redirect(url_for('routes.assistant'))
    return render_template('login.html', form=form)

@routes.route('/signup', methods=['GET', 'POST'])
def signup():
    form = SignupForm()
    if form.validate_on_submit():
        user = User(username=form.username.data, email=form.email.data)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('routes.login'))
    return render_template('signup.html', form=form)

@routes.route('/assistant', methods=['GET', 'POST'])
def assistant():
    if 'user_id' not in session:
        return redirect(url_for('routes.login'))

    if request.method == 'POST':
        if 'audio' in request.files:
            audio_file = request.files['audio']
            user_input = transcribe_audio(audio_file)
        else:
            user_input = request.json['input']

        response = process_user_input(user_input)
        return jsonify({'response': response})

    return render_template('assistant.html')

@routes.route('/guide')
def guide():
    return render_template('guide.html')
    
@routes.route('/profile')
def profile():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        form = ProfileUpdateForm(obj=user)
        return render_template('profile.html', current_user=user, form=form)
    return redirect(url_for('routes.login'))

@routes.route('/profile/update', methods=['POST'])
def profile_update():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        form = ProfileUpdateForm()
        if form.validate_on_submit():
            user.username = form.username.data
            user.email = form.email.data
            db.session.commit()
            flash('Profile updated successfully!', 'success')
            return redirect(url_for('routes.profile'))
        return render_template('profile.html', current_user=user, form=form)
    return redirect(url_for('routes.login'))

@routes.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('routes.login'))  # Changed from index to login

@routes.route('/features')
def features():
    return render_template('index.html', scroll_to="#features")

@routes.route('/subscribe', methods=['GET', 'POST'])
def subscribe():
    form = SubscriptionForm()
    if form.validate_on_submit():
        selected_plan = form.plan.data
        amount = 0
        if selected_plan == 'Standard':
            amount = 1000  # $10
        elif selected_plan == 'Premium':
            amount = 2000  # $20

        # Create a Stripe Checkout Session
        session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': f"{selected_plan} Plan"
                    },
                    'unit_amount': amount,
                },
                'quantity': 1,
            }],
            mode='payment',
            success_url=url_for('routes.payment_success', _external=True),
            cancel_url=url_for('routes.payment_cancel', _external=True),
        )

        return redirect(session.url, code=303)

    return render_template('pricing.html', form=form)

@routes.route('/payment-success')
def payment_success():
    if 'user_id' in session:
        user = User.query.get(session['user_id'])
        if user:
            user.subscription_status = "Premium"  # Update the user's subscription status
            db.session.commit()
            flash("Payment successful! Your subscription has been updated to Premium.", "success")
    return redirect(url_for('routes.profile'))

@routes.route('/payment-cancel')
def payment_cancel():
    return "Payment was canceled. Please try again."
