document.addEventListener('DOMContentLoaded', () => {
    const inputField = document.getElementById('assistant-input');
    const outputDiv = document.getElementById('assistant-output');
    const askButton = document.getElementById('button-ask');
    const recordButton = document.getElementById('button-record');
  
    const userName = "Boss";
    let isSpeaking = false;
    let micActive = false;
    let serialPort = null;
  
    const predefinedCommands = {
        'open youtube': () => openSite('https://www.youtube.com', 'Opening YouTube...'),
        'open github': () => openSite('https://www.github.com', 'Opening GitHub...'),
        'open facebook': () => openSite('https://www.facebook.com', 'Opening Facebook...'),
        'open twitter': () => openSite('https://www.twitter.com', 'Opening Twitter...'),
        'open linkedin': () => openSite('https://www.linkedin.com', 'Opening LinkedIn...'),
        'open instagram': () => openSite('https://www.instagram.com', 'Opening Instagram...'),
        'play music': () => openSite('https://music.youtube.com/watch?v=XO8wew38VM8&list=OLAK5uy_liFpkvwf-4WbtSaTpkYnt98R0u_Wsu04k', 'Playing Music Online...'),
        'what is the time': () => respondWithTime(),
        'what is the date': () => respondWithDate(),
        'what is my battery level': () => checkBatteryLevel(),
        'what is the weather': () => fetchWeatherData(),
        'calculate': (expression) => calculateExpression(expression),
        'tell me about': (topic) => searchWikipedia(topic),
        'play song': () => initiateMusicSearch(),
        'shutdown device': () => shutdownDevice(),
        'restart device': () => restartDevice(),
        'sleep device': () => sleepDevice(),
        'search youtube': (query) => searchYouTube(query),
        'find on google': (query) => searchGoogle(query),
        'turn on bulb': () => controlBulb('ON'),
        'turn off bulb': () => controlBulb('OFF')
    };


 // New Arduino Bulb Control Function
 async function controlBulb(state) {
    if (!('serial' in navigator)) {
        displayAndSpeakResponse("Web Serial API not supported.");
        return;
    }

    try {
        // Request port with more specific filters
        const port = await navigator.serial.requestPort({
            filters: [
                { usbVendorId: 0x2341 },  // Arduino generic vendor ID
                { usbProductId: 0x0043 }  // Uno specific product ID
            ]
        });

        // Open port with extended configuration
        await port.open({ 
            baudRate: 9600,
            dataBits: 8,
            stopBits: 1,
            parity: 'none'
        });

        const writer = port.writable.getWriter();
        const encoder = new TextEncoder();
        const data = encoder.encode(state + '\n');
        
        await writer.write(data);
        writer.releaseLock();

        displayAndSpeakResponse(`Bulb turned ${state.toLowerCase()}`);
        
        // Optional: Close port after command
        await port.close();
    } catch (error) {
        console.error('Detailed Bulb Control Error:', error);
        displayAndSpeakResponse("Failed to control bulb. Check Arduino connection.");
    }
}


  // Wikipedia Search Function
  function searchWikipedia(topic) {
    const searchUrl = `https://en.wikipedia.org/w/index.php?search=${encodeURIComponent(topic)}`;
    displayAndSpeakResponse(`Searching Wikipedia for information about ${topic}...`);
    setTimeout(() => {
        window.open(searchUrl, '_blank');
    }, 2000);
}

// Music Search Function
function initiateMusicSearch() {
    displayAndSpeakResponse("Would you like to search for a specific song or play a random playlist?");
    // This could be expanded with more interactive logic
    setTimeout(() => {
        const searchUrl = 'https://music.youtube.com/';
        window.open(searchUrl, '_blank');
    }, 2000);
}

// Device Control Functions
function shutdownDevice() {
    displayAndSpeakResponse("Initiating device shutdown. Please save all your work.");
    // Note: Actual shutdown requires system-level permissions
    alert("Device shutdown command triggered. This is a simulated response.");
}

function restartDevice() {
    displayAndSpeakResponse("Restarting device. Please wait a moment.");
    // Note: Actual restart requires system-level permissions
    alert("Device restart command triggered. This is a simulated response.");
}

function sleepDevice() {
    displayAndSpeakResponse("Putting the device to sleep mode.");
    // Note: Actual sleep mode requires system-level permissions
    alert("Device sleep command triggered. This is a simulated response.");
}

// YouTube Search Function
function searchYouTube(query) {
    const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`;
    displayAndSpeakResponse(`Searching YouTube for ${query}...`);
    setTimeout(() => {
        window.open(searchUrl, '_blank');
    }, 2000);
}

// Google Search Function
function searchGoogle(query) {
    const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    displayAndSpeakResponse(`Searching Google for ${query}...`);
    setTimeout(() => {
        window.open(searchUrl, '_blank');
    }, 2000);
}

  function openSite(url, responseMessage) {
      displayAndSpeakResponse(responseMessage);
      setTimeout(() => {
          window.open(url, '_blank');
      }, 2000); // Wait for the speech synthesis to complete before redirection.
  }

  function respondWithTime() {
      const currentTime = new Date().toLocaleTimeString();
      displayAndSpeakResponse(`The current time is ${currentTime}`);
  }

  function respondWithDate() {
      const currentDate = new Date().toLocaleDateString();
      displayAndSpeakResponse(`Today's date is ${currentDate}`);
  }

  async function checkBatteryLevel() {
      try {
          const battery = await navigator.getBattery();
          const level = battery.level * 100;
          displayAndSpeakResponse(`Your battery level is ${level.toFixed(2)}%.`);
      } catch (error) {
          displayAndSpeakResponse("Sorry, I couldn't retrieve the battery level.");
      }
  }

  async function fetchWeatherData() {
      try {
          const response = await fetch('https://api.openweathermap.org/data/2.5/weather?q=India&appid=3e89f882c90a1d99b70491775297aa67&units=metric');
          const weatherData = await response.json();
          const { name, weather, main } = weatherData;
          const weatherDescription = weather[0].description;
          const temperature = main.temp;
          displayAndSpeakResponse(`The weather in ${name} is ${weatherDescription} with a temperature of ${temperature}°C.`);
      } catch (error) {
          displayAndSpeakResponse("Sorry, I couldn't fetch the weather information.");
      }
  }

  function calculateExpression(expression) {
      try {
          const result = eval(expression);
          displayAndSpeakResponse(`The result is ${result}`);
      } catch {
          displayAndSpeakResponse("Sorry, I couldn't perform the calculation.");
      }
  }

  function greetUser(name) {
      const greeting = `Hello ${name}, welcome back! How can I assist you today?`;
      displayAndSpeakResponse(greeting);
  }

  function displayAndSpeakResponse(response) {
      outputDiv.innerHTML = response;
      speak(response);
  }

  function speak(message) {
      isSpeaking = true;
      const speech = new SpeechSynthesisUtterance(message);
      speech.lang = 'en-US';
      speech.onend = () => {
          isSpeaking = false; // Allow interactions after speaking ends.
      };
      speechSynthesis.speak(speech);
  }

   // Enhanced Voice Recognition
   function startVoiceRecognition() {
    if ('webkitSpeechRecognition' in window) {
        const recognition = new webkitSpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = () => {
            micActive = true;
            console.log('Voice recognition started.');
        };

        recognition.onresult = async (event) => {
            if (isSpeaking) {
                recognition.stop();
                return;
            }
            const userInput = event.results[0][0].transcript.trim().toLowerCase();
            await processUserInput(userInput);
        };

        recognition.onerror = (event) => {
            displayAndSpeakResponse("Sorry, there was an error with voice recognition.");
            console.error("Voice recognition error:", event.error);
        };

        recognition.onend = () => {
            micActive = false;
            console.log("Voice recognition ended.");
        };

        recognition.start();
    } else {
        displayAndSpeakResponse("Sorry, your browser does not support voice recognition.");
    }
}


// Enhanced processUserInput to handle async calls
async function processUserInput(input) {
    if (isSpeaking) return;

    for (const command in predefinedCommands) {
        if (input.includes(command)) {
            const extractedTopic = input.replace(command, '').trim();
            
            if (['tell me about', 'search youtube', 'find on google', 'calculate'].includes(command)) {
                predefinedCommands[command](extractedTopic);
            } else {
                predefinedCommands[command]();
            }
            return;
        }
    }
    
    displayAndSpeakResponse(`I'm searching Google for: ${input}`);
    setTimeout(() => {
        window.open(`https://www.google.com/search?q=${encodeURIComponent(input)}`, '_blank');
    }, 2000);
}

// Existing event listeners and initial setup
greetUser(userName);

askButton.addEventListener('click', () => {
    const userInput = inputField.value.trim();
    processUserInput(userInput);
    inputField.value = '';
});

recordButton.addEventListener('click', () => {
    if (isSpeaking) {
        displayAndSpeakResponse("Please wait until I finish speaking.");
        return;
    }
    startVoiceRecognition();
});

});
