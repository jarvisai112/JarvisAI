import openai
import speech_recognition as sr

openai.api_key = "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"

def process_user_input(input_text):
    # Use OpenAI's GPT-3.5-turbo to generate a response
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "user", "content": input_text}
        ],
        max_tokens=1024,
        n=1,
        stop=None,
        temperature=0.7,
    )

    assistant_response = response.choices[0].message.content.strip()
    return assistant_response

def transcribe_audio(audio_file):
    r = sr.Recognizer()
    with sr.AudioFile(audio_file) as source:
        audio = r.record(source)

    try:
        text = r.recognize_google(audio)
        return text
    except sr.UnknownValueError:
        print("Speech Recognition could not understand audio")
        return "I'm sorry, I didn't catch that. Could you please try again?"
    except sr.RequestError as e:
        print("Could not request results from Speech Recognition service; {0}".format(e))
        return "I'm sorry, there was an error processing your audio. Please try again later."